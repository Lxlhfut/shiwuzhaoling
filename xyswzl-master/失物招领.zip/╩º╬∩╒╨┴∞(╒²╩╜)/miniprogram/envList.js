const envList = [{"envId":"xgj1-056iz","alias":"xgj1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}